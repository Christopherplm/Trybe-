function Header() {
  return (
    <header>
      <h1>Gerenciador de senhas</h1>
    </header>
  );
}

export default Header;
