import { ChangeEvent, useState } from 'react';
import Register from './Register';

function Form() {
  const [showForm, setShowForm] = useState(false);

  const [name, setName] = useState('');
  const [login, setLogin] = useState('');
  const [password, setPassword] = useState('');

  const handleName = (event: ChangeEvent<HTMLInputElement>) => {
    setName(event.target.value);
  };

  const handleLogin = (event: ChangeEvent<HTMLInputElement>) => {
    setLogin(event.target.value);
  };

  const handlePassword = (event: ChangeEvent<HTMLInputElement>) => {
    const newRequest = event.target.value;
    const requirement = passwordRegex(newRequest);
    if (requirement) {
      setPassword(event.target.value);
    } else {
      setPassword('');
    }
  };

  const validForm = name && login && password;

  const passwordRegex = (senha: string) => {
    const regex = /^(?=.[A-Za-z])(?=.\d)(?=.[@$!%#?&])[A-Za-z\d@$!%*#?&]{8,16}$/;
    return (
      regex.test(senha)
    );
  };

  const handleCancel = () => {
    setShowForm(!showForm);
  };

  return (
    <div>
      {showForm ? (
        <Register onClick={ () => setShowForm(false) } />
      )
        : (
          <form action="">
            <label htmlFor="name">
              Nome do serviço
              <input type="text" id="name" required onChange={ handleName } />
            </label>

            <label htmlFor="login">
              Login
              <input type="text" id="login" required onChange={ handleLogin } />
            </label>

            <label htmlFor="password">
              Senha
              <input type="password" id="password" required onChange={ handlePassword } />
            </label>

            <label htmlFor="url">
              URL
              <input type="text" id="url" />
            </label>

            <button disabled={ !validForm }> Cadastrar </button>
            <button type="button" onClick={ handleCancel }> Cancelar </button>
          </form>

        )}
    </div>
  );
}

export default Form;
