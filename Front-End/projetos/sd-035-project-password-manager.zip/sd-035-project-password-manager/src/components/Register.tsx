type RegisterProps = {
  onClick: () => void;
};

function Register({ onClick }: RegisterProps) {
  const handleClick = onClick;
  return (
    <button
      onClick={ handleClick }
    >
      Cadastrar nova senha
    </button>
  );
}

export default Register;
