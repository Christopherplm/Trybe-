import './App.css';

import { useState } from 'react';

import Header from './components/Header';
import Form from './components/Form';
import Register from './components/Register';

function App() {
  const [showForm, setShowForm] = useState(false);
  const handleClick = () => {
    setShowForm(true);
  };
  return (
    <div>
      <Header />
      {showForm ? <Form /> : <Register onClick={ handleClick } />}
    </div>
  );
}

export default App;
